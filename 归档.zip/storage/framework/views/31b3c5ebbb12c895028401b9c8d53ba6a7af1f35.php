<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div>
        <p class="bg-warning">翻译类别数字解释：  0:"牌匾印章",
1:"证照公函",
        2:"字词短句",
        3:"人名地名",
        4:"学术论文",
        5:"法律法规",
        6:"标书文件",
        7:"说明书"</p>
        <p class="bg-warning">翻译方式：  1:汉语<->传统蒙文；
2:"汉语<->西里尔蒙文"；
        3:"传统蒙文<->西里尔蒙文",</p>

        
        
        <div class="panel panel-default">
            <div class="panel-heading">
                <h1>
                    <i class="glyphicon glyphicon-align-justify"></i> 所有订单
                    
                    
                </h1>
            </div>
            
        <br/>
            <div class="panel-body">
                <?php if($orders->count()): ?>
                
                    <table class="table table-condensed table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th>订单名称</th> <th>订单号</th> <th>微信商户订单</th> <th>微信名称</th><th>手机号码</th> <th>翻译类别</th> 
                                <th>翻译方式</th> <th>翻译内容</th> <th>翻译字数</th> 
                                <th>价格</th> <th>支付状态</th>  <th>支付成功时间</th>  <th>是否翻译完成</th>
                                <th class="text-right">操作</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if($orders ): ?>
                                
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($order->name); ?></td> <td><?php echo e($order->uuid); ?></td> <td><?php echo e($order->wechat_order_id); ?></td> 
                                    <td><?php echo e($order->nickname); ?></td>
                                     <td><?php echo e($order->phone); ?></td> <td><?php echo e($order->categories); ?></td> 
                                     <td><?php echo e($order->type); ?></td> <td><?php echo e($order->body); ?></td> <td><?php echo e($order->text_count); ?></td> <td><?php echo e($order->unit_price); ?></td> <td><?php echo e($order->count_price); ?></td> <td><?php echo e($order->payment_state); ?></td> <td><?php echo e($order->paid_at); ?></td> <td><?php echo e($order->is_ok); ?></td>
                                    
                                    <td class="text-right">
                                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('orders.show', $order->id)); ?>">
                                            <i class="glyphicon glyphicon-eye-open"></i> 
                                        </a>
                                        
                                        <a class="btn btn-xs btn-warning" href="<?php echo e(route('orders.edit', $order->id)); ?>">
                                            <i class="glyphicon glyphicon-edit"></i> 
                                        </a>

                                        <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Delete? Are you sure?');">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE">

                                            <button type="submit" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-trash"></i> </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo $orders->render(); ?>

                <?php else: ?>
                    <h3 class="text-center alert alert-info">Empty!</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>